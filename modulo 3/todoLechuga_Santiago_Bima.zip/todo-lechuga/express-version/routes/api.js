var express = require('express');
var router = express.Router();
var novedadesModels = require('../models/novedades');
var prodModels = require('../models/productos');
var cloudinary = require('cloudinary');
var nodemailer = require('nodemailer');

router.get('/novedades', async function (req, res, next) {
    let novedades = await novedadesModels.getNovedades();

    res.json(novedades);
})

router.get('/productos', async function (req, res, next) {
    let prods = await prodModels.getProd();
    prods=prods.map(prod=>{
        const imagen=cloudinary.image(prod.imagen,{
          width: 200,
          height: 170,
          crop: 'fill'
        });
        return{
          ...prod,imagen
        }
    })

    res.json(prods);
})

router.get('/tipos', async function (req, res, next) {
  let tipos = await prodModels.getProdType();

  res.json(tipos);
})


router.post('/contacto', async (req, res) => {
  const mail ={
    to: 'santiago.bima@gmail.com',
    subject: 'contacto web',
    html: `${req.body.nombre} se contacto a traves de la web y quiere mas informacion a este correo: ${req.body.email} <br>
    Además, hizo el siguiente comentario: ${req.body.mensaje} <br>
    Su tel es: ${req.body.telefono}`
  }

  var transport = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_PORT,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });

  await transport.sendMail(mail);

  res.status(201).json({
    error: false,
    message: 'Mensaje enviado'
  })
})

module.exports = router;