import React, { Component } from 'react';
import './styles/Footer.css';

export default class Footer extends Component {
    render() {
        return (
            <>
                <p>Diseñado por Santiago Bima - &copy;año</p>
            </>
        )
    }
}
